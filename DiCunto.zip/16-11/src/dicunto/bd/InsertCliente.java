package dicunto.bd;

import static dicunto.bd.ConexaoMySQL.getConexaoMySQL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class InsertCliente extends ConexaoMySQL{
    
    public static void setInserirCliente(String nome, String endreco, String bairro, int numero, 
                                    String cidade, int cep, String estado, String email, String cpf, 
                                    int dtnascimento, int celular, int telefone){
    
        
    
         
         
                    try{
                        
                        
                        Connection con = getConexaoMySQL();
                        
                        
                            PreparedStatement insert = con.prepareStatement
            ("INSERT INTO CLIENTE (NOME, ENDERECO, BAIRRO, NUMERO, CIDADE, CEP, ESTADO, EMAIL, CPF, DATA_NASCIMENTO, CELULAR, TELEFONE) "
                + "VALUES ( '"+nome+"', '"+endreco+"', '"+bairro+"', '"+numero+"','"+cidade+"', '"+cep+"', '"+estado+"', '"+email+"','"+cpf+"', '"+dtnascimento+"', '"+celular+"', '"+telefone+"' ) ");
                        
                            insert.executeUpdate();
                            
                    }catch(Exception e){System.out.println(e);}
        
            finally{
                     
                    System.out.println("CLIENTE INSERIDO COM SUCESSO !");
                    
                        JOptionPane.showMessageDialog(null,  "CLIENTE INSERIDO COM SUCESSO !");
                        
                    }
                        
                    
        
        
    
}        

    
    
}

package dicunto.bd;

import static dicunto.bd.ConexaoMySQL.getConexaoMySQL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class InserirFuncionario extends ConexaoMySQL{
    
    public static void setInserirFuncionario(String nome, String cargo, String setor, String endreco, String bairro, int numero, 
                                    String cidade, int cep, String estado, String email, String cpf, 
                                    int dtadmissao, int dtnascimento, int celular, int telefone, int telefone2){
    
        
    
         
         
                    try{
                        
                        
                        Connection con = getConexaoMySQL();
                        
                        
                            PreparedStatement insert = con.prepareStatement
("INSERT INTO FUNCIONARIO (NOME, CARGO, SETOR, ENDERECO, BAIRRO, NUMERO, CIDADE, CEP, ESTADO, EMAIL, CPF, DATA_ADMISSAO, DATA_NASCIMENTO, CELULAR, TELEFONE, TELEFONE2) "
                + "VALUES ( '"+nome+"', '"+cargo+"', '"+setor+"','"+endreco+"', '"+bairro+"', '"+numero+"','"+cidade+"', '"+cep+"', '"+estado+"', '"+email+"','"+cpf+"', '"+dtadmissao+"', '"+dtnascimento+"','"+celular+"', '"+telefone+"', '"+telefone2+"' ) ");                                                
                           
                            insert.executeUpdate();
                            
                    }catch(Exception e){System.out.println(e);}
        
            finally{
                     
                    System.out.println("FUNCIONARIO INSERIDO COM SUCESSO !");
                    
                                            JOptionPane.showMessageDialog(null,  "FUNCIONARIO INSERIDO COM SUCESSO !");

                        
                    }
                        
                    
        
        
    
}        

    
    
}

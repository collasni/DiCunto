package dicunto.bd;

import static dicunto.bd.ConexaoMySQL.getConexaoMySQL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class InserirCategoria extends ConexaoMySQL{

    public static void setInserirCategoria(String nome, String descricao){
    
        
    
         
         
                    try{
                        
                        
                        Connection con = getConexaoMySQL();
                        
                        
                            PreparedStatement insert = con.prepareStatement("INSERT INTO CATEGORIA (NOME, DESCRICAO) VALUES ( '"+nome+"', '"+descricao+"') ");
                        
                            insert.executeUpdate();
                            
                    }catch(Exception e){System.out.println(e);}
        
            finally{
                     
                    System.out.println("CATEGORIA INSERIDO COM SUCESSO !");
                    
                                            JOptionPane.showMessageDialog(null,  "CATEGORIA INSERIDO COM SUCESSO !");

                        
                    }
                        
                    
        
        
    
}        

    

    
}

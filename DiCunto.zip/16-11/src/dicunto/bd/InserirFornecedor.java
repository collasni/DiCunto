package dicunto.bd;

import static dicunto.bd.ConexaoMySQL.getConexaoMySQL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class InserirFornecedor extends ConexaoMySQL{


public static void setInserirFornecedor(String nome, String endreco, String bairro, int numero, 
                                    String cidade, int cep, String estado, String email, String cnpj, 
                                    int dtcadastro, int celular, int telefone, int telefone2){
    
        
    
         
         
                    try{
                        
                        
                        Connection con = getConexaoMySQL();
                        
                        
                            PreparedStatement insert = con.prepareStatement
            ("INSERT INTO FORNECEDOR (NOME, ENDERECO, BAIRRO, NUMERO, CIDADE, CEP, ESTADO, EMAIL, CNPJ, DATA_CADASTRO, CELULAR, TELEFONE, TELEFONE2) "
                + "VALUES ( '"+nome+"', '"+endreco+"', '"+bairro+"', '"+numero+"','"+cidade+"', '"+cep+"', '"+estado+"', '"+email+"','"+cnpj+"', '"+dtcadastro+"', '"+celular+"', '"+telefone+"', '"+telefone2+"' ) ");
                        
                            insert.executeUpdate();
                            
                    }catch(Exception e){System.out.println(e);}
        
            finally{
                     
                    System.out.println("FORNECEDOR INSERIDO COM SUCESSO !");
                    
                                            JOptionPane.showMessageDialog(null,  "FORNECEDOR INSERIDO COM SUCESSO !");

                        
                    }
                        
                    
        
        
    
}        


    
}

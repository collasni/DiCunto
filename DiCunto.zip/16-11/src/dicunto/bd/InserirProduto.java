package dicunto.bd;

import static dicunto.bd.ConexaoMySQL.getConexaoMySQL;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class InserirProduto extends ConexaoMySQL{

    public static void setInserirProduto(int v_fornecedor, int v_categoria, int v_quantidade, String v_descricao, double v_preco, double v_peso ){
    
        
    
         
         
                    try{
                        
                        
                        Connection con = getConexaoMySQL();
                        
                        
PreparedStatement insert = con.prepareStatement("INSERT INTO PRODUTO (ID_FORNECEDOR , ID_CATEGORIA , QUANTIDADE , DESCRICAO, PRECO , PESO ) VALUES ( '"+v_fornecedor+"', '"+v_categoria+"', '"+v_quantidade+"', '"+v_descricao+"', '"+v_preco+"', '"+v_peso+"') ");
                        
                            insert.executeUpdate();
                            
                    }catch(Exception e){System.out.println(e);}
        
            finally{
                     
                    System.out.println("PRODUTO INSERIDO COM SUCESSO !");
                        
                    }
                        
                    
        
        
    
}        


    
}

package dicunto.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JFrame;

public class Principal extends JFrame {

    private final JFrame frm;
    
    public Principal(JFrame frm) {
        this.frm = frm;
        
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        painelPrincipal = new javax.swing.JPanel();
        btnLogo = new javax.swing.JButton();
        btnCaixa = new javax.swing.JButton();
        btnCliente = new javax.swing.JButton();
        btnFornecedor = new javax.swing.JButton();
        btnFuncionario = new javax.swing.JButton();
        btnRelatorio = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        btnProduto = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Confeitaria Di Cunto");
        setBackground(new java.awt.Color(255, 239, 231));
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setExtendedState(6);
        setForeground(new java.awt.Color(0, 0, 0));
        setLocation(new java.awt.Point(0, 0));
        setLocationByPlatform(true);
        setMinimumSize(new java.awt.Dimension(1024, 768));
        setName(""); // NOI18N
        setPreferredSize(new java.awt.Dimension(1024, 768));
        setSize(new java.awt.Dimension(1069, 715));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new java.awt.GridLayout(1, 0));

        painelPrincipal.setBackground(new java.awt.Color(255, 239, 231));
        painelPrincipal.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(226, 157, 38), 5, true));
        painelPrincipal.setAutoscrolls(true);
        painelPrincipal.setPreferredSize(new java.awt.Dimension(500, 500));
        painelPrincipal.setLayout(new java.awt.GridBagLayout());

        btnLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Logo/Logo_Vetor_700x400.png"))); // NOI18N
        btnLogo.setBorder(null);
        btnLogo.setBorderPainted(false);
        btnLogo.setContentAreaFilled(false);
        btnLogo.setFocusPainted(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 11;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        painelPrincipal.add(btnLogo, gridBagConstraints);

        btnCaixa.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        btnCaixa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Caixa/Caixa.png"))); // NOI18N
        btnCaixa.setText("CAIXA");
        btnCaixa.setBorder(null);
        btnCaixa.setBorderPainted(false);
        btnCaixa.setContentAreaFilled(false);
        btnCaixa.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCaixa.setFocusPainted(false);
        btnCaixa.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCaixa.setMinimumSize(new java.awt.Dimension(200, 200));
        btnCaixa.setPreferredSize(new java.awt.Dimension(150, 200));
        btnCaixa.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnCaixa.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCaixa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCaixaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnCaixaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnCaixaMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnCaixaMouseReleased(evt);
            }
        });
        btnCaixa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCaixaActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        painelPrincipal.add(btnCaixa, gridBagConstraints);

        btnCliente.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        btnCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Cliente/Cliente.png"))); // NOI18N
        btnCliente.setText("CLIENTE");
        btnCliente.setBorder(null);
        btnCliente.setBorderPainted(false);
        btnCliente.setContentAreaFilled(false);
        btnCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCliente.setFocusPainted(false);
        btnCliente.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCliente.setMinimumSize(new java.awt.Dimension(200, 200));
        btnCliente.setPreferredSize(new java.awt.Dimension(150, 200));
        btnCliente.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnCliente.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnClienteMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnClienteMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnClienteMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnClienteMouseReleased(evt);
            }
        });
        btnCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClienteActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 4;
        painelPrincipal.add(btnCliente, gridBagConstraints);

        btnFornecedor.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        btnFornecedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Fornecedor/Fornecedor.png"))); // NOI18N
        btnFornecedor.setText("FORNECEDOR");
        btnFornecedor.setBorder(null);
        btnFornecedor.setBorderPainted(false);
        btnFornecedor.setContentAreaFilled(false);
        btnFornecedor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnFornecedor.setFocusPainted(false);
        btnFornecedor.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnFornecedor.setMinimumSize(new java.awt.Dimension(200, 200));
        btnFornecedor.setPreferredSize(new java.awt.Dimension(150, 200));
        btnFornecedor.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnFornecedor.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnFornecedor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnFornecedorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnFornecedorMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnFornecedorMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnFornecedorMouseReleased(evt);
            }
        });
        btnFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFornecedorActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 4;
        painelPrincipal.add(btnFornecedor, gridBagConstraints);

        btnFuncionario.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        btnFuncionario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Funcionario/Funcionario.png"))); // NOI18N
        btnFuncionario.setText("FUNCIONÁRIO");
        btnFuncionario.setBorder(null);
        btnFuncionario.setBorderPainted(false);
        btnFuncionario.setContentAreaFilled(false);
        btnFuncionario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnFuncionario.setFocusPainted(false);
        btnFuncionario.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnFuncionario.setMinimumSize(new java.awt.Dimension(200, 200));
        btnFuncionario.setPreferredSize(new java.awt.Dimension(150, 200));
        btnFuncionario.setVerifyInputWhenFocusTarget(false);
        btnFuncionario.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnFuncionario.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnFuncionario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnFuncionarioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnFuncionarioMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnFuncionarioMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnFuncionarioMouseReleased(evt);
            }
        });
        btnFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFuncionarioActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 8;
        gridBagConstraints.gridy = 4;
        painelPrincipal.add(btnFuncionario, gridBagConstraints);

        btnRelatorio.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        btnRelatorio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Relatorio/Relatorio.png"))); // NOI18N
        btnRelatorio.setText("RELATÓRIO");
        btnRelatorio.setBorder(null);
        btnRelatorio.setBorderPainted(false);
        btnRelatorio.setContentAreaFilled(false);
        btnRelatorio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnRelatorio.setFocusPainted(false);
        btnRelatorio.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnRelatorio.setMinimumSize(new java.awt.Dimension(200, 200));
        btnRelatorio.setPreferredSize(new java.awt.Dimension(150, 200));
        btnRelatorio.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnRelatorio.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnRelatorio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnRelatorioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnRelatorioMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnRelatorioMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnRelatorioMouseReleased(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 10;
        gridBagConstraints.gridy = 4;
        painelPrincipal.add(btnRelatorio, gridBagConstraints);

        jPanel1.setBackground(new java.awt.Color(255, 239, 231));
        jPanel1.setMinimumSize(new java.awt.Dimension(30, 20));
        jPanel1.setOpaque(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        painelPrincipal.add(jPanel1, gridBagConstraints);

        jPanel2.setBackground(new java.awt.Color(255, 239, 231));
        jPanel2.setMinimumSize(new java.awt.Dimension(30, 20));
        jPanel2.setOpaque(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 5;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        painelPrincipal.add(jPanel2, gridBagConstraints);

        jPanel3.setBackground(new java.awt.Color(255, 239, 231));
        jPanel3.setMinimumSize(new java.awt.Dimension(30, 20));
        jPanel3.setOpaque(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 7;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        painelPrincipal.add(jPanel3, gridBagConstraints);

        jPanel4.setBackground(new java.awt.Color(255, 239, 231));
        jPanel4.setMinimumSize(new java.awt.Dimension(30, 20));
        jPanel4.setOpaque(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 9;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        painelPrincipal.add(jPanel4, gridBagConstraints);

        jPanel5.setBackground(new java.awt.Color(255, 239, 231));
        jPanel5.setMinimumSize(new java.awt.Dimension(30, 30));
        jPanel5.setOpaque(false);
        jPanel5.setPreferredSize(new java.awt.Dimension(30, 30));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 12;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        painelPrincipal.add(jPanel5, gridBagConstraints);

        btnProduto.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        btnProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Produto/Produto.png"))); // NOI18N
        btnProduto.setText("Produto");
        btnProduto.setBorder(null);
        btnProduto.setBorderPainted(false);
        btnProduto.setContentAreaFilled(false);
        btnProduto.setFocusPainted(false);
        btnProduto.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnProduto.setMaximumSize(new java.awt.Dimension(129, 155));
        btnProduto.setMinimumSize(new java.awt.Dimension(200, 200));
        btnProduto.setPreferredSize(new java.awt.Dimension(150, 200));
        btnProduto.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnProduto.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnProduto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnProdutoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnProdutoMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnProdutoMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                btnProdutoMouseReleased(evt);
            }
        });
        btnProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProdutoActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 12;
        gridBagConstraints.gridy = 4;
        painelPrincipal.add(btnProduto, gridBagConstraints);

        jPanel6.setOpaque(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 11;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        painelPrincipal.add(jPanel6, gridBagConstraints);

        getContentPane().add(painelPrincipal);

        setSize(new java.awt.Dimension(1117, 818));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
       this.getContentPane().setBackground(Color.getHSBColor((float) 0.055555552, (float) 0.09411765, (float) 1.0));  
        // TODO add your handling code here:
    }//GEN-LAST:event_formWindowOpened

    private void btnCaixaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCaixaActionPerformed
        
        new Caixa(this).setVisible(true);
        
    }//GEN-LAST:event_btnCaixaActionPerformed

    private void btnClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClienteActionPerformed
        
        new CadastroCliente(this).setVisible(true);
        

        
    }//GEN-LAST:event_btnClienteActionPerformed

    private void btnFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFornecedorActionPerformed

        new CadastroFornecedor(this).setVisible(true);
        
        
    }//GEN-LAST:event_btnFornecedorActionPerformed

    private void btnFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFuncionarioActionPerformed

        new CadastroFuncionario(this).setVisible(true);
        
        
        
    }//GEN-LAST:event_btnFuncionarioActionPerformed

    private void btnProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProdutoActionPerformed
        
        new CadastroProduto(this).setVisible(true);
        
    }//GEN-LAST:event_btnProdutoActionPerformed

    private void btnCaixaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCaixaMouseEntered
        
        
        btnCaixa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Caixa/CaixaMouse.png")));
        
        
    }//GEN-LAST:event_btnCaixaMouseEntered

    private void btnCaixaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCaixaMouseExited
        
        btnCaixa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Caixa/Caixa.png")));
        
    }//GEN-LAST:event_btnCaixaMouseExited

    private void btnClienteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnClienteMouseEntered
        
                btnCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Cliente/ClienteMouse.png"))); // NOI18N

        
    }//GEN-LAST:event_btnClienteMouseEntered

    private void btnClienteMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnClienteMouseExited
        
                btnCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Cliente/Cliente.png"))); // NOI18N

        
    }//GEN-LAST:event_btnClienteMouseExited

    private void btnFornecedorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFornecedorMouseEntered

        
                btnFornecedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Fornecedor/FornecedorMouse.png"))); // NOI18N

        
    }//GEN-LAST:event_btnFornecedorMouseEntered

    private void btnFornecedorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFornecedorMouseExited

        
                btnFornecedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Fornecedor/Fornecedor.png"))); // NOI18N

        
    }//GEN-LAST:event_btnFornecedorMouseExited

    private void btnFuncionarioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFuncionarioMouseEntered
        
                btnFuncionario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Funcionario/FuncionarioMouse.png"))); // NOI18N
        
        
    }//GEN-LAST:event_btnFuncionarioMouseEntered

    private void btnFuncionarioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFuncionarioMouseExited

                btnFuncionario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Funcionario/Funcionario.png"))); // NOI18N

        
    }//GEN-LAST:event_btnFuncionarioMouseExited

    private void btnRelatorioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRelatorioMouseEntered

                btnRelatorio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Relatorio/RelatorioMouse.png"))); // NOI18N

        
    }//GEN-LAST:event_btnRelatorioMouseEntered

    private void btnRelatorioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRelatorioMouseExited

                btnRelatorio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Relatorio/Relatorio.png"))); // NOI18N

        
    }//GEN-LAST:event_btnRelatorioMouseExited

    private void btnProdutoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnProdutoMouseEntered

                btnProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Produto/ProdutoMouse.png"))); // NOI18N

        
    }//GEN-LAST:event_btnProdutoMouseEntered

    private void btnProdutoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnProdutoMouseExited

                btnProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Produto/Produto.png"))); // NOI18N

        
    }//GEN-LAST:event_btnProdutoMouseExited

    private void btnRelatorioMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRelatorioMouseReleased

                                btnRelatorio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Relatorio/RelatorioMouse.png"))); // NOI18N

        
        
    }//GEN-LAST:event_btnRelatorioMouseReleased

    private void btnRelatorioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRelatorioMousePressed

        
                                btnRelatorio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Relatorio/MouseClick.png"))); // NOI18N

        
    }//GEN-LAST:event_btnRelatorioMousePressed

    private void btnProdutoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnProdutoMousePressed

                btnProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Produto/MouseClick.png"))); // NOI18N

        
    }//GEN-LAST:event_btnProdutoMousePressed

    private void btnProdutoMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnProdutoMouseReleased

                btnProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Produto/ProdutoMouse.png"))); // NOI18N

        
    }//GEN-LAST:event_btnProdutoMouseReleased

    private void btnFuncionarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFuncionarioMousePressed

                btnFuncionario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Funcionario/MouseClick.png"))); // NOI18N

        
    }//GEN-LAST:event_btnFuncionarioMousePressed

    private void btnFuncionarioMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFuncionarioMouseReleased

                btnFuncionario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Funcionario/FuncionarioMouse.png"))); // NOI18N

        
    }//GEN-LAST:event_btnFuncionarioMouseReleased

    private void btnFornecedorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFornecedorMousePressed

        
                btnFornecedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Fornecedor/MouseClick.png"))); // NOI18N

        
    }//GEN-LAST:event_btnFornecedorMousePressed

    private void btnFornecedorMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnFornecedorMouseReleased

        
                btnFornecedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Fornecedor/FornecedorMouse.png"))); // NOI18N

        
    }//GEN-LAST:event_btnFornecedorMouseReleased

    private void btnClienteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnClienteMousePressed

        
                btnCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Cliente/MouseClick.png"))); // NOI18N

        
    }//GEN-LAST:event_btnClienteMousePressed

    private void btnClienteMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnClienteMouseReleased

        
                btnCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Cliente/ClienteMouse.png"))); // NOI18N

        
    }//GEN-LAST:event_btnClienteMouseReleased

    private void btnCaixaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCaixaMousePressed

        
                btnCaixa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Caixa/MouseClick.png"))); // NOI18N

        
    }//GEN-LAST:event_btnCaixaMousePressed

    private void btnCaixaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCaixaMouseReleased

        
                btnCaixa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dicunto/img/Caixa/CaixaMouse.png"))); // NOI18N

        
    }//GEN-LAST:event_btnCaixaMouseReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCaixa;
    private javax.swing.JButton btnCliente;
    private javax.swing.JButton btnFornecedor;
    private javax.swing.JButton btnFuncionario;
    private javax.swing.JButton btnLogo;
    private javax.swing.JButton btnProduto;
    private javax.swing.JButton btnRelatorio;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel painelPrincipal;
    // End of variables declaration//GEN-END:variables
}

package dicunto.gui;

import dicunto.bd.ConexaoMySQL;
import static dicunto.bd.InserirFornecedor.setInserirFornecedor;
import javax.swing.JFrame;

public class CadastroFornecedor extends javax.swing.JFrame {
    
    private final JFrame frm;

    public CadastroFornecedor(JFrame frm) {
        
        this.frm = frm;
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lblNome = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        lblEndereco = new javax.swing.JLabel();
        txtEndereco = new javax.swing.JTextField();
        lblnumero = new javax.swing.JLabel();
        txtnumero = new javax.swing.JTextField();
        lblBairro = new javax.swing.JLabel();
        txtBairro = new javax.swing.JTextField();
        lblCidade = new javax.swing.JLabel();
        txtCidade = new javax.swing.JTextField();
        lblEstado = new javax.swing.JLabel();
        txtEstado = new javax.swing.JTextField();
        lblCep = new javax.swing.JLabel();
        txtCep = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        lblCpf = new javax.swing.JLabel();
        txtCnpj = new javax.swing.JTextField();
        lblNascimento = new javax.swing.JLabel();
        txtcadastro = new javax.swing.JTextField();
        lblTelefone = new javax.swing.JLabel();
        txtTelefone = new javax.swing.JTextField();
        lblCelular = new javax.swing.JLabel();
        txtCelular = new javax.swing.JTextField();
        btnCadastrar = new javax.swing.JButton();
        lblTitulo = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        telefone2 = new javax.swing.JTextField();
        jPanel12 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1001, 721));
        setMinimumSize(new java.awt.Dimension(1001, 721));
        setResizable(false);
        getContentPane().setLayout(new java.awt.GridLayout(1, 0));

        jPanel1.setBackground(new java.awt.Color(255, 239, 231));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(226, 157, 38), 5, true));
        jPanel1.setAutoscrolls(true);
        jPanel1.setMaximumSize(new java.awt.Dimension(1001, 721));
        jPanel1.setMinimumSize(new java.awt.Dimension(1001, 721));
        jPanel1.setPreferredSize(new java.awt.Dimension(1001, 721));
        jPanel1.setLayout(new java.awt.GridBagLayout());

        jPanel2.setBackground(new java.awt.Color(255, 239, 231));
        jPanel2.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        jPanel2.setMaximumSize(new java.awt.Dimension(10, 50));
        jPanel2.setMinimumSize(new java.awt.Dimension(10, 50));
        jPanel2.setPreferredSize(new java.awt.Dimension(10, 50));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 40;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(jPanel2, gridBagConstraints);

        lblNome.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        lblNome.setText("Nome");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(lblNome, gridBagConstraints);

        txtNome.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtNome.setText("Dougras");
        txtNome.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(108, 44, 21), 2, true));
        txtNome.setMinimumSize(new java.awt.Dimension(300, 28));
        txtNome.setPreferredSize(new java.awt.Dimension(300, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(txtNome, gridBagConstraints);

        lblEndereco.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        lblEndereco.setText("Endereço");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 17;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(lblEndereco, gridBagConstraints);

        txtEndereco.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtEndereco.setText("Dougras");
        txtEndereco.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(108, 44, 21), 2, true));
        txtEndereco.setPreferredSize(new java.awt.Dimension(300, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 17;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(txtEndereco, gridBagConstraints);

        lblnumero.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        lblnumero.setText("Nº");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 35;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 9;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(lblnumero, gridBagConstraints);

        txtnumero.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtnumero.setText("185");
        txtnumero.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(108, 44, 21), 2, true));
        txtnumero.setPreferredSize(new java.awt.Dimension(50, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 35;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 9;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(txtnumero, gridBagConstraints);

        lblBairro.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        lblBairro.setText("Bairro");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 17;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(lblBairro, gridBagConstraints);

        txtBairro.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtBairro.setText("Dougras");
        txtBairro.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(108, 44, 21), 2, true));
        txtBairro.setPreferredSize(new java.awt.Dimension(300, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 17;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(txtBairro, gridBagConstraints);

        lblCidade.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        lblCidade.setText("Cidade");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 17;
        gridBagConstraints.gridy = 9;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(lblCidade, gridBagConstraints);

        txtCidade.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtCidade.setText("Dougras");
        txtCidade.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(108, 44, 21), 2, true));
        txtCidade.setPreferredSize(new java.awt.Dimension(200, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 17;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(txtCidade, gridBagConstraints);

        lblEstado.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        lblEstado.setText("Estado");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 35;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.gridwidth = 9;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(lblEstado, gridBagConstraints);

        txtEstado.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtEstado.setText("DG");
        txtEstado.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(108, 44, 21), 2, true));
        txtEstado.setPreferredSize(new java.awt.Dimension(50, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 35;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.gridwidth = 9;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(txtEstado, gridBagConstraints);

        lblCep.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        lblCep.setText("CEP");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 17;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(lblCep, gridBagConstraints);

        txtCep.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtCep.setText("14587905");
        txtCep.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(108, 44, 21), 2, true));
        txtCep.setPreferredSize(new java.awt.Dimension(150, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 17;
        gridBagConstraints.gridy = 13;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(txtCep, gridBagConstraints);

        lblEmail.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        lblEmail.setText("E-mail");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(lblEmail, gridBagConstraints);

        txtEmail.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtEmail.setText("Dougras");
        txtEmail.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(108, 44, 21), 2, true));
        txtEmail.setPreferredSize(new java.awt.Dimension(300, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(txtEmail, gridBagConstraints);

        lblCpf.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        lblCpf.setText("CNPJ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 35;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(lblCpf, gridBagConstraints);

        txtCnpj.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtCnpj.setText("54187498566324");
        txtCnpj.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(108, 44, 21), 2, true));
        txtCnpj.setPreferredSize(new java.awt.Dimension(200, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 35;
        gridBagConstraints.gridy = 13;
        gridBagConstraints.gridwidth = 10;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(txtCnpj, gridBagConstraints);

        lblNascimento.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        lblNascimento.setText("Data de cadastro");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 35;
        gridBagConstraints.gridy = 9;
        gridBagConstraints.gridwidth = 9;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(lblNascimento, gridBagConstraints);

        txtcadastro.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtcadastro.setText("666666");
        txtcadastro.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(108, 44, 21), 2, true));
        txtcadastro.setPreferredSize(new java.awt.Dimension(150, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 35;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.gridwidth = 9;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(txtcadastro, gridBagConstraints);

        lblTelefone.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        lblTelefone.setText("Telefone");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 9;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(lblTelefone, gridBagConstraints);

        txtTelefone.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtTelefone.setText("66666");
        txtTelefone.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(108, 44, 21), 2, true));
        txtTelefone.setPreferredSize(new java.awt.Dimension(200, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(txtTelefone, gridBagConstraints);

        lblCelular.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        lblCelular.setText("Celular");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 15;
        gridBagConstraints.gridwidth = 9;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(lblCelular, gridBagConstraints);

        txtCelular.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtCelular.setText("4444444");
        txtCelular.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(108, 44, 21), 2, true));
        txtCelular.setPreferredSize(new java.awt.Dimension(200, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 16;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(txtCelular, gridBagConstraints);

        btnCadastrar.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        btnCadastrar.setText("Cadastrar");
        btnCadastrar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(108, 44, 21), 2, true));
        btnCadastrar.setContentAreaFilled(false);
        btnCadastrar.setMinimumSize(new java.awt.Dimension(100, 50));
        btnCadastrar.setPreferredSize(new java.awt.Dimension(100, 50));
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 15;
        gridBagConstraints.gridy = 24;
        gridBagConstraints.gridwidth = 4;
        jPanel1.add(btnCadastrar, gridBagConstraints);

        lblTitulo.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        lblTitulo.setText("Cadastro de Fornecedor");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 13;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 21;
        jPanel1.add(lblTitulo, gridBagConstraints);

        jPanel19.setBackground(new java.awt.Color(255, 239, 231));
        jPanel19.setMinimumSize(new java.awt.Dimension(30, 30));
        jPanel19.setPreferredSize(new java.awt.Dimension(30, 30));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(jPanel19, gridBagConstraints);

        jPanel20.setBackground(new java.awt.Color(255, 239, 231));
        jPanel20.setMinimumSize(new java.awt.Dimension(30, 30));
        jPanel20.setPreferredSize(new java.awt.Dimension(30, 30));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(jPanel20, gridBagConstraints);

        jPanel21.setBackground(new java.awt.Color(255, 239, 231));
        jPanel21.setMinimumSize(new java.awt.Dimension(30, 30));
        jPanel21.setPreferredSize(new java.awt.Dimension(30, 30));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 11;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(jPanel21, gridBagConstraints);

        jPanel22.setBackground(new java.awt.Color(255, 239, 231));
        jPanel22.setMinimumSize(new java.awt.Dimension(30, 30));
        jPanel22.setPreferredSize(new java.awt.Dimension(30, 30));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 14;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(jPanel22, gridBagConstraints);

        jPanel25.setBackground(new java.awt.Color(255, 239, 231));
        jPanel25.setMinimumSize(new java.awt.Dimension(30, 30));
        jPanel25.setPreferredSize(new java.awt.Dimension(30, 30));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 23;
        gridBagConstraints.gridwidth = 40;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(jPanel25, gridBagConstraints);

        jLabel1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel1.setText("Telefone 2");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 12;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(jLabel1, gridBagConstraints);

        telefone2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        telefone2.setText("8888888");
        telefone2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(108, 44, 21), 2, true));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 13;
        gridBagConstraints.gridwidth = 15;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(telefone2, gridBagConstraints);

        jPanel12.setBackground(new java.awt.Color(255, 239, 231));
        jPanel12.setMaximumSize(new java.awt.Dimension(20, 20));
        jPanel12.setMinimumSize(new java.awt.Dimension(20, 20));
        jPanel12.setPreferredSize(new java.awt.Dimension(20, 20));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 16;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridheight = 14;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel1.add(jPanel12, gridBagConstraints);

        jPanel3.setBackground(new java.awt.Color(255, 239, 231));
        jPanel3.setMaximumSize(new java.awt.Dimension(20, 20));
        jPanel3.setMinimumSize(new java.awt.Dimension(20, 20));
        jPanel3.setPreferredSize(new java.awt.Dimension(20, 20));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 33;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridheight = 13;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        jPanel1.add(jPanel3, gridBagConstraints);

        getContentPane().add(jPanel1);

        setSize(new java.awt.Dimension(1017, 760));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed

                setInserirFornecedor(txtNome.getText(), txtEndereco.getText(), txtBairro.getText(), Integer.parseInt(txtnumero.getText()), 
                txtCidade.getText(), Integer.parseInt(txtCep.getText()), txtEstado.getText(), txtEmail.getText(), txtCnpj.getText(),
                Integer.parseInt(txtcadastro.getText()), Integer.parseInt(txtCelular.getText()), Integer.parseInt(txtTelefone.getText()), Integer.parseInt(telefone2.getText()));
        
    }//GEN-LAST:event_btnCadastrarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblBairro;
    private javax.swing.JLabel lblCelular;
    private javax.swing.JLabel lblCep;
    private javax.swing.JLabel lblCidade;
    private javax.swing.JLabel lblCpf;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblEndereco;
    private javax.swing.JLabel lblEstado;
    private javax.swing.JLabel lblNascimento;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblTelefone;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblnumero;
    private javax.swing.JTextField telefone2;
    private javax.swing.JTextField txtBairro;
    private javax.swing.JTextField txtCelular;
    private javax.swing.JTextField txtCep;
    private javax.swing.JTextField txtCidade;
    private javax.swing.JTextField txtCnpj;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtEstado;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtTelefone;
    private javax.swing.JTextField txtcadastro;
    private javax.swing.JTextField txtnumero;
    // End of variables declaration//GEN-END:variables
}
